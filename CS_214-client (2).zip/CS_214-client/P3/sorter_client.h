struct file_dir{
	char *wDir;
	char *oDir;
	char *sF;
	char *curr_dir;
	char *host_name;
	int port;
	int compare;
};
